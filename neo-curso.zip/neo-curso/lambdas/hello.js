

// creamos nuestra primera lambda

//no hagan esto en casa es solo para entendimiento de la base de datos
const list = [];

exports.world = async (event, context) => {


    const pathMethod = event.httpMethod;
    const pathResource = event.resource;

    const route = pathMethod.concat(" ").concat(pathResource);
    const body = JSON.parse(event.body);
    let rta = 'No object';

    switch (route) {
        case "POST /user":

            list.push(body)
            rta = 'save user';
            break;

        case "GET /user":
            rta = list;
            break;
    }

    const user = {
        name: "dante",
        pass: "123"
    }

    return {
        statusCode: 200,
        headers: {
            "Content-type": "application/json"
        },
        body: JSON.stringify(rta)
    }
}