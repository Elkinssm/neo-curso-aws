

// creamos nuestra primera lambda

exports.world = async (event, context) =>{


    const pathMethod = event.httpMethod;
    const pathResource = event.resource;

    const route = pathMethod.concat(" ").concat(pathResource);



    const user = {
        name: "dante",
        pass: "123"
    }

    return {
        statusCode:200,
        headers: {
            "Content-type":"application/json"
        },
        body: JSON.stringify(route)
    }
}